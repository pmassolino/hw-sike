/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include "xparameters.h"
#include "xstatus.h"
#include "xil_types.h"
#include "xil_assert.h"
#include "xuartps_hw.h"
#include "xil_printf.h"
#include "xil_io.h"
#include <xuartps.h>


#define SIDH_BASE_ADDRESS (0x43C00000)
#define SIDH_IS_FREE      (0x0000E001*4)

int main()
{
	u8 send_buffer[34] = "Start serial interface with FPGA\n\n";
	u8 recv_buffer[8];
	u32 recv_addr;
	u32 recv_amount;
	u32 recv_data;
	u32 send_data;
	u32 send_amount;
	XUartPs uart_Ps;
	XUartPs_Config *config;
	u32 i;

	init_platform();

	config = XUartPs_LookupConfig(XPAR_PS7_UART_1_DEVICE_ID);
    XUartPs_CfgInitialize(&uart_Ps, config, config->BaseAddress);
	for(i = 100000; i != 0; i--){;}

	//XUartPs_Send(&uart_Ps, send_buffer, 34);
	while (1) {
		recv_amount = 0;
		while(recv_amount < 6){
			recv_amount += XUartPs_Recv(&uart_Ps, &recv_buffer[recv_amount], 6 - recv_amount);
		}
		recv_addr = 0;
		recv_addr = recv_buffer[3];
		recv_addr = recv_addr << 8;
		recv_addr = recv_addr | recv_buffer[2];
		recv_addr = recv_addr << 8;
		recv_addr = recv_addr | recv_buffer[1];
		recv_addr += SIDH_BASE_ADDRESS;

		recv_data = 0;
		recv_data = recv_buffer[5];
		recv_data = recv_data << 8;
		recv_data = recv_data | recv_buffer[4];
		if(recv_buffer[0] == 0x01) {
			/* Read data into bus */
			send_data = 0;
			send_data = Xil_In32(recv_addr);
			send_buffer[0] = (send_data & 0xFF);
			send_buffer[1] = ((send_data >> 8) & 0xFF);
		}
		else if(recv_buffer[0] == 0x02) {
			/* Write data into bus */
			Xil_Out32(recv_addr, recv_data);
			send_buffer[0] = 0xff;
			send_buffer[1] = 0xff;
		}
		else if(recv_buffer[0] == 0x04) {
			send_data = 0;
			send_data = Xil_In32(SIDH_BASE_ADDRESS+SIDH_IS_FREE);
			send_buffer[0] = (send_data & 0xFF);
			send_buffer[1] = 0x00;
		}
		else {
			send_buffer[0] = 0x00;
			send_buffer[1] = 0x00;
		}
		send_amount = 0;
		while(send_amount < 2){
			send_amount += XUartPs_Send(&uart_Ps, &send_buffer[send_amount], 2 - send_amount);
		}
		for(i = 10000; i != 0; i--){;}
	}

    cleanup_platform();
    return 0;
}
